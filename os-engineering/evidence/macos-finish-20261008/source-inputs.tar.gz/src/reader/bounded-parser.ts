import { unified } from "unified";
import remarkParse from "remark-parse";
import remarkGfm from "remark-gfm";
import remarkFrontmatter from "remark-frontmatter";
import type { Root } from "mdast";
import { boundedBlocks, type BoundedBlock } from "./block-budget";
import { parseFrontmatter } from "./frontmatter";

const parser = unified().use(remarkParse).use(remarkGfm).use(remarkFrontmatter);
export const MAX_DOCUMENT = 10 * 1024 * 1024;
const MAX_PARSE_BYTES = 128 * 1024;
const MAX_CHUNK = 64 * 1024;

/** Linear preflight, before any parser allocation; applied to each source region. */
export function expensiveShape(source: string): boolean {
  let line = 0, pipes = 0, total = 0, lines = 0;
  for (let i = 0; i < source.length; i++) {
    if (source[i] === "\n") { line = 0; pipes = 0; if (++lines > 4096) return true; }
    else {
      if (++line > 8192) return true;
      if (source[i] === "|" && (++pipes > 128 || ++total > 4096)) return true;
    }
  }
  return /^(?:[ \t]*>[ \t]*){65}/m.test(source);
}

function footnotes(tree: Root) {
  const numbers = new Map<string, number>();
  const visits = new Map<string, number>();
  const pending: any[] = [...tree.children].reverse();
  while (pending.length) {
    const node = pending.pop();
    if (node.type === "footnoteReference" && !numbers.has(node.identifier)) numbers.set(node.identifier, numbers.size + 1);
    if (node.children) pending.push(...[...node.children].reverse());
  }
  const walk: any[] = [...tree.children];
  while (walk.length) {
    const node = walk.pop();
    if (node.type === "footnoteReference") {
      const key = encodeURIComponent(node.identifier), number = numbers.get(node.identifier);
      const visit = (visits.get(key) ?? 0) + 1; visits.set(key, visit);
      Object.assign(node, { type: "emphasis", data: { hName: "sup" }, children: [{ type: "link", url: `#fn-${key}`,
        data: { hProperties: { id: `fnref-${key}-${visit}` } },
        children: [{ type: "text", value: String(number) }] }] });
    } else if (node.type === "footnoteDefinition") {
      const key = encodeURIComponent(node.identifier), number = numbers.get(node.identifier);
      Object.assign(node, { type: "blockquote", data: { hName: "section", hProperties: { id: `fn-${key}` } }, children: [
        { type: "paragraph", children: [{ type: "text", value: `[${number ?? node.identifier}] ` },
          { type: "link", url: `#fnref-${key}-1`, children: [{ type: "text", value: "↩" }] }] }, ...node.children] });
    }
    if (node.children) walk.push(...node.children);
  }
}

export function parseBounded(source: string) {
  const empty = (): Root => ({ type: "root", children: [] });
  const fallback = (text: string): BoundedBlock => ({ tree: empty(), source: text, fallback: true });
  if (source.length > MAX_DOCUMENT) return { tree: empty(), blocks: [fallback(source)], metadata: null };
  // Ordinary small documents retain the parser's full document semantics.
  if (source.length <= MAX_CHUNK && !expensiveShape(source)) {
    const tree = parser.parse(source) as Root;
    const first = tree.children[0] as any;
    const metadata = first?.type === "yaml" ? parseFrontmatter(first.value) : null;
    footnotes(tree);
    return { tree, blocks: boundedBlocks(tree, source), metadata };
  }
  // Partition only at unindented blank-line boundaries, outside fenced code
  // and frontmatter. Oversized regions are retained exactly, never parsed.
  const regions: Array<{ start: number; end: number }> = [];
  let start = 0, offset = 0, fence = "", front = source.startsWith("---\n"), firstLine = true;
  const lines = source.matchAll(/[^\n]*(?:\n|$)/g);
  for (const match of lines) {
    const line = match[0]; if (!line) continue;
    const marker = /^(?: {0,3})(`{3,}|~{3,})/.exec(line)?.[1];
    if (front) { if (!firstLine && /^(?:---|\.\.\.)\s*$/.test(line)) front = false; }
    else if (marker && !fence) fence = marker;
    else if (marker && marker[0] === fence[0] && marker.length >= fence.length) fence = "";
    offset += line.length;
    if (!front && !fence && /^\s*\n$/.test(line) && offset > start) {
      regions.push({ start, end: offset }); start = offset;
    }
    firstLine = false;
    if (regions.length >= 4096) break;
  }
  if (start < source.length) regions.push({ start, end: source.length });
  // Bounded document definitions make references resolve across parse regions.
  let context = "";
  for (const match of source.matchAll(/^ {0,3}\[(?:\^)?[^\]\n]{1,256}\]:[^\n]*(?:\n(?: {2,}|\t)[^\n]*)*/gm)) {
    if (context.length + match[0].length > 32768) break;
    context += `${match[0]}\n\n`;
  }
  const tree = empty(); const rejected = new Map<number, string>();
  let parsedBytes = 0, exhausted = false;
  for (const region of regions) {
    const text = source.slice(region.start, region.end);
    if (text.length <= MAX_CHUNK && !expensiveShape(text)
      && parsedBytes + text.length + context.length > MAX_PARSE_BYTES) exhausted = true;
    if (text.length > MAX_CHUNK || expensiveShape(text) || exhausted) {
      rejected.set(tree.children.length, text);
      tree.children.push({ type: "code", value: text, data: { hProperties: { "data-budget-fallback": true } },
        position: { start: { line: 1, column: 1, offset: region.start }, end: { line: 1, column: 1, offset: region.end } } });
      continue;
    }
    parsedBytes += text.length + context.length;
    try {
      const part = parser.parse(text + "\n\n" + context) as Root;
      const original = part.children.filter(node => (node.position?.start.offset ?? 0) < text.length);
      const pending: any[] = [...original];
      while (pending.length) {
        const node = pending.pop();
        if (node.position) { node.position.start.offset += region.start; node.position.end.offset += region.start; }
        if (node.children) pending.push(...node.children);
      }
      tree.children.push(...original);
    } catch { rejected.set(tree.children.length, text); tree.children.push({ type: "code", value: text }); }
  }
  const first = tree.children[0] as any;
  const metadata = first?.type === "yaml" ? parseFrontmatter(first.value) : null;
  footnotes(tree);
  const blocks = boundedBlocks(tree, source);
  for (const [index, text] of rejected) if (index < 2048 && blocks[index]) blocks[index] = fallback(text);
  const compact: BoundedBlock[] = [];
  for (const block of blocks) {
    const previous = compact.at(-1);
    if (block.fallback && previous?.fallback) previous.source += block.source;
    else compact.push(block);
  }
  return { tree: { ...tree, children: compact.flatMap(block => block.tree.children) }, blocks: compact, metadata };
}
