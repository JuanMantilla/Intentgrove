import { api } from "../app/api";
export interface DiagramPixels { jobId: string; generation: number; width: number; height: number; bytes: number[] }
interface Job { id: string; generation: number; source: string; cancelled: boolean; resolve: (value: DiagramPixels) => void; reject: (error: Error) => void }
const queue: Job[] = [];
let active: Job | null = null;
let generation = 0;
const failure = () => new Error("Diagram unavailable; source is preserved");
function validPixels(value: DiagramPixels, job: Job): boolean {
  if (!value || typeof value !== "object" || value.jobId !== job.id || value.generation !== job.generation || !Number.isInteger(value.width) || !Number.isInteger(value.height) || value.width < 1 || value.height < 1 || value.width > 2048 || value.height > 2048 || !Array.isArray(value.bytes) || value.bytes.length < 24 || value.bytes.length > 4*1024*1024) return false;
  return value.bytes.every(byte => Number.isInteger(byte) && byte >= 0 && byte <= 255)
    && [137,80,78,71,13,10,26,10].every((byte,index) => value.bytes[index] === byte)
    && String.fromCharCode(...value.bytes.slice(12,16)) === "IHDR"
    && new DataView(new Uint8Array(value.bytes.slice(16,24)).buffer).getUint32(0) === value.width
    && new DataView(new Uint8Array(value.bytes.slice(16,24)).buffer).getUint32(4) === value.height;
}
function drain() {
  if (active) return;
  const job = queue.shift();
  if (!job) return;
  if (job.cancelled) { drain(); return; }
  active = job;
  let request: Promise<DiagramPixels>;
  try { request=api.renderDiagram(job.source,job.id,job.generation); }
  catch { job.reject(failure());active=null;drain();return; }
  void request.then(value => {
    if (!job.cancelled) {
      if (validPixels(value,job)) job.resolve(value); else job.reject(failure());
    }
  }, () => { if (!job.cancelled) job.reject(failure()); }).finally(() => { active=null;drain(); });
}
export function renderDiagram(source: string): { promise: Promise<DiagramPixels>; cancel: () => void } {
  let job: Job | undefined;
  const promise = new Promise<DiagramPixels>((resolve,reject) => {
    if (new TextEncoder().encode(source).length > 32768 || queue.length + Number(Boolean(active)) >= 32) { reject(failure()); return; }
    job = { id: crypto.randomUUID(),generation:++generation,source,cancelled:false,resolve,reject };
    queue.push(job);drain();
  });
  return { promise,cancel: () => {
    if (!job || job.cancelled) return;
    job.cancelled=true;job.reject(failure());
    const index=queue.indexOf(job);if(index>=0) queue.splice(index,1);
    if(active===job) void api.cancelDiagram(job.id).catch(error => { console.error("Diagram cancellation failed; native deadline remains active", error); });
  } };
}
