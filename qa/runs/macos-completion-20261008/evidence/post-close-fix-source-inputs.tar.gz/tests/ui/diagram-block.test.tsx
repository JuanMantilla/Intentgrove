// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, render, screen } from "@testing-library/react";
import MarkdownView from "../../src/reader/MarkdownView";
const mocks=vi.hoisted(()=>({render:vi.fn(),cancel:vi.fn().mockResolvedValue(undefined)}));
vi.mock("../../src/app/api",()=>({api:{renderDiagram:mocks.render,cancelDiagram:mocks.cancel}}));
afterEach(()=>{cleanup();vi.unstubAllGlobals();vi.restoreAllMocks();});
it("renders an inert diagram and preserves malformed source and neighboring content",async()=>{
 vi.stubGlobal("Worker",undefined);vi.spyOn(URL,"createObjectURL").mockReturnValue("blob:diagram");vi.spyOn(URL,"revokeObjectURL").mockImplementation(()=>{});
 mocks.render.mockImplementation((source:string,jobId:string,generation:number)=>source.includes("broken")?Promise.reject(Error("parse")):Promise.resolve({jobId,generation,width:24,height:16,bytes:[137,80,78,71,13,10,26,10,0,0,0,13,73,72,68,82,0,0,0,24,0,0,0,16]}));
 render(<MarkdownView content={"Before\n\n```mermaid\nflowchart LR\nA-->B\n```\n\nBetween\n\n```mermaid\nflowchart broken\n```\n\nAfter"} fileId="fixture" locale="en" onNavigate={()=>{}}/>);
 expect((await screen.findByAltText("Mermaid diagram")).getAttribute("src")).toBe("blob:diagram");expect((await screen.findByRole("alert")).textContent).toContain("Diagram unavailable");expect(screen.getByText("flowchart broken")).toBeTruthy();for(const label of ["Before","Between","After"])expect(screen.getByText(label)).toBeTruthy();expect(document.querySelector("svg,iframe")).toBeNull();
});
